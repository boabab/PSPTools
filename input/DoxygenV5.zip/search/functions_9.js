var searchData=
[
  ['readsram_5fexternal_452',['readSRAM_external',['../os__mem__drivers_8c.html#a4fa256c45a80ac4b5e4eba352afb1304',1,'os_mem_drivers.c']]],
  ['readsram_5finternal_453',['readSRAM_internal',['../os__mem__drivers_8c.html#adb15019f570eaaef26ffa759a9feedc4',1,'os_mem_drivers.c']]]
];
