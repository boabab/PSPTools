var searchData=
[
  ['max_5fnumber_5fof_5fprocesses_108',['MAX_NUMBER_OF_PROCESSES',['../defines_8h.html#a57c4c2d31ce05f6034d5356eb9e366f2',1,'defines.h']]],
  ['memaddr_109',['MemAddr',['../os__mem__drivers_8h.html#a671f889b349dc7e2c2a1e5f92eba14b3',1,'os_mem_drivers.h']]],
  ['memdriver_110',['MemDriver',['../os__mem__drivers_8h.html#adfc637edabdc40893c2153747e1f3e0d',1,'MemDriver():&#160;os_mem_drivers.h'],['../struct_mem_driver.html',1,'MemDriver']]],
  ['memoryinithnd_111',['MemoryInitHnd',['../os__mem__drivers_8h.html#a00865258fee93669414c3ac095af269f',1,'os_mem_drivers.h']]],
  ['memoryreadhnd_112',['MemoryReadHnd',['../os__mem__drivers_8h.html#a8d4e16045644e0fd149e49aeee1bdf6c',1,'os_mem_drivers.h']]],
  ['memorywritehnd_113',['MemoryWriteHnd',['../os__mem__drivers_8h.html#ad2b868d497695f539b38ee82ce28f54f',1,'os_mem_drivers.h']]],
  ['memvalue_114',['MemValue',['../os__mem__drivers_8h.html#ab43e10401c502f3ac0d57e02a95b8cad',1,'os_mem_drivers.h']]],
  ['mlfq_5fgetdefaulttimeslice_115',['MLFQ_getDefaultTimeslice',['../os__scheduling__strategies_8c.html#aced6f1a87294783a6fa0d14cd72f96b0',1,'MLFQ_getDefaultTimeslice(uint8_t queueID):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#aced6f1a87294783a6fa0d14cd72f96b0',1,'MLFQ_getDefaultTimeslice(uint8_t queueID):&#160;os_scheduling_strategies.c']]],
  ['mlfq_5fgetqueue_116',['MLFQ_getQueue',['../os__scheduling__strategies_8c.html#abb8b69e7ca8b2c9fb5a9d77cdb493a84',1,'MLFQ_getQueue(uint8_t queueID):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a629ffd3298efa00373e999a7d4d8fd32',1,'MLFQ_getQueue(uint8_t queueID):&#160;os_scheduling_strategies.c']]],
  ['mlfq_5fmaptoqueue_117',['MLFQ_MapToQueue',['../os__scheduling__strategies_8c.html#a95d2cb3869eb1152b7f3a1e3e42f24e5',1,'MLFQ_MapToQueue(Priority prio):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a95d2cb3869eb1152b7f3a1e3e42f24e5',1,'MLFQ_MapToQueue(Priority prio):&#160;os_scheduling_strategies.c']]],
  ['mlfq_5fremovepid_118',['MLFQ_removePID',['../os__scheduling__strategies_8c.html#afec6e9db0f495ab73d7b28f2158d8c5f',1,'MLFQ_removePID(ProcessID pid):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#afec6e9db0f495ab73d7b28f2158d8c5f',1,'MLFQ_removePID(ProcessID pid):&#160;os_scheduling_strategies.c']]],
  ['movechunk_119',['moveChunk',['../os__memory_8c.html#a1c8691648bd2d5114b97de7cc2550bc2',1,'os_memory.c']]]
];
