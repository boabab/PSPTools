var searchData=
[
  ['gethighnibble_332',['getHighNibble',['../os__memory_8c.html#a09b73f1d91f025749a3e8840de58bd06',1,'os_memory.c']]],
  ['getlownibble_333',['getLowNibble',['../os__memory_8c.html#a2aab9a8f722e2c71f427ebc9631120c6',1,'os_memory.c']]],
  ['getownerofchunk_334',['getOwnerOfChunk',['../os__memory_8c.html#a92f361aa7a656c7fb1d07143e27952cc',1,'os_memory.c']]]
];
