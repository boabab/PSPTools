var searchData=
[
  ['extheap_541',['extHeap',['../os__memheap__drivers_8h.html#a9d3e12d77e5d6a64c38d9d52a4aef469',1,'os_memheap_drivers.h']]],
  ['extsram_542',['extSRAM',['../os__mem__drivers_8h.html#aab38e0df15a7e7bbdc0de32e168b1daa',1,'os_mem_drivers.h']]]
];
