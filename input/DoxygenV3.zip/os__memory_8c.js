var os__memory_8c =
[
    [ "getHighNibble", "os__memory_8c.html#a09b73f1d91f025749a3e8840de58bd06", null ],
    [ "getLowNibble", "os__memory_8c.html#a2aab9a8f722e2c71f427ebc9631120c6", null ],
    [ "getOwnerOfChunk", "os__memory_8c.html#a92f361aa7a656c7fb1d07143e27952cc", null ],
    [ "os_free", "os__memory_8c.html#a345f569e1a9a5d0a6012c76ee1b0f65c", null ],
    [ "os_freeOwnerRestricted", "os__memory_8c.html#ae30934b438eca830815f445a1144a8c2", null ],
    [ "os_freeProcessMemory", "os__memory_8c.html#ac97dfa6f209b8979ac658f93814aa71f", null ],
    [ "os_getAllocationStrategy", "os__memory_8c.html#a6bbc386efe8f2b9ef7d0197239a9ceb7", null ],
    [ "os_getChunkSize", "os__memory_8c.html#ac0d23d85efdcf2dfb01180948214074b", null ],
    [ "os_getFirstByteOfChunk", "os__memory_8c.html#aaa69e86c67d117013f2ff4680c476170", null ],
    [ "os_getMapEntry", "os__memory_8c.html#a9af7a326526068e8016d6e8ad95b4a59", null ],
    [ "os_getMapSize", "os__memory_8c.html#abf1f1d6eeab0f72f6eed9097ce64acc3", null ],
    [ "os_getMapStart", "os__memory_8c.html#afc5ad3e031d4d0ec57645d0886bf5f3f", null ],
    [ "os_getUseSize", "os__memory_8c.html#a2bf045ff7b6b54955473bb02058db3c9", null ],
    [ "os_getUseStart", "os__memory_8c.html#a8c4372f410ab7ac261879ea61b6980ab", null ],
    [ "os_malloc", "os__memory_8c.html#a5644c571680a5c019c91c30bee4d5d7e", null ],
    [ "os_setAllocationStrategy", "os__memory_8c.html#a6e809f1786f114791ae1e8d8abfb39d2", null ],
    [ "setHighNibble", "os__memory_8c.html#a68640fd1f0d9f708b30091fa70ff9ee6", null ],
    [ "setLowNibble", "os__memory_8c.html#a706bb11a3d86c04a12526367ed7c3313", null ],
    [ "setMapEntry", "os__memory_8c.html#a9a3813198496fd4b10db2a6eedd27b99", null ]
];