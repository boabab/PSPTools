var searchData=
[
  ['sethighnibble_378',['setHighNibble',['../os__memory_8c.html#a68640fd1f0d9f708b30091fa70ff9ee6',1,'os_memory.c']]],
  ['setlownibble_379',['setLowNibble',['../os__memory_8c.html#a706bb11a3d86c04a12526367ed7c3313',1,'os_memory.c']]],
  ['setmapentry_380',['setMapEntry',['../os__memory_8c.html#a9a3813198496fd4b10db2a6eedd27b99',1,'os_memory.c']]]
];
