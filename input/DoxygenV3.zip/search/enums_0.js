var searchData=
[
  ['accesspermission_419',['AccessPermission',['../os__user__privileges_8h.html#a79e573249a2843d17c2469e7f9d62899',1,'os_user_privileges.h']]],
  ['allocstrategy_420',['AllocStrategy',['../os__memheap__drivers_8h.html#adefc48149844c3ceffb7771bbb89d5fb',1,'os_memheap_drivers.h']]]
];
