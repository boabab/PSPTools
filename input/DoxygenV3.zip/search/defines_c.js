var searchData=
[
  ['register_5fautostart_494',['REGISTER_AUTOSTART',['../os__process_8h.html#a0d6a80de559a050450ba3ed62e461cc2',1,'os_process.h']]],
  ['restorecontext_495',['restoreContext',['../util_8h.html#a9c44075f57f61dc7b14637f1973776bc',1,'util.h']]]
];
