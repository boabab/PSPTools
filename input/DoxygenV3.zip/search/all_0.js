var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../os__scheduler_8c.html#a2804a023941a956288c32ad08b2cf59e',1,'os_scheduler.c']]],
  ['_5f_5fheap_5fstart_1',['__heap_start',['../os__core_8h.html#aa1b242a8ba3e152cede356fe4e176ff6',1,'os_core.h']]]
];
