var searchData=
[
  ['mlfq_5fgetdefaulttimeslice_419',['MLFQ_getDefaultTimeslice',['../os__scheduling__strategies_8c.html#aced6f1a87294783a6fa0d14cd72f96b0',1,'MLFQ_getDefaultTimeslice(uint8_t queueID):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#aced6f1a87294783a6fa0d14cd72f96b0',1,'MLFQ_getDefaultTimeslice(uint8_t queueID):&#160;os_scheduling_strategies.c']]],
  ['mlfq_5fgetqueue_420',['MLFQ_getQueue',['../os__scheduling__strategies_8c.html#abb8b69e7ca8b2c9fb5a9d77cdb493a84',1,'MLFQ_getQueue(uint8_t queueID):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a629ffd3298efa00373e999a7d4d8fd32',1,'MLFQ_getQueue(uint8_t queueID):&#160;os_scheduling_strategies.c']]],
  ['mlfq_5fmaptoqueue_421',['MLFQ_MapToQueue',['../os__scheduling__strategies_8c.html#a95d2cb3869eb1152b7f3a1e3e42f24e5',1,'MLFQ_MapToQueue(Priority prio):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a95d2cb3869eb1152b7f3a1e3e42f24e5',1,'MLFQ_MapToQueue(Priority prio):&#160;os_scheduling_strategies.c']]],
  ['mlfq_5fremovepid_422',['MLFQ_removePID',['../os__scheduling__strategies_8c.html#afec6e9db0f495ab73d7b28f2158d8c5f',1,'MLFQ_removePID(ProcessID pid):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#afec6e9db0f495ab73d7b28f2158d8c5f',1,'MLFQ_removePID(ProcessID pid):&#160;os_scheduling_strategies.c']]],
  ['movechunk_423',['moveChunk',['../os__memory_8c.html#a1c8691648bd2d5114b97de7cc2550bc2',1,'os_memory.c']]]
];
