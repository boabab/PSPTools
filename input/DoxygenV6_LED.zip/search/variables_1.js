var searchData=
[
  ['autostart_5fhead_516',['autostart_head',['../os__process_8h.html#a3bf06243b3e3b8fa8ab5e23fa21d9b76',1,'os_process.c']]]
];
