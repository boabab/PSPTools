var searchData=
[
  ['savecontext_295',['saveContext',['../util_8h.html#a95d67df1cf6117ce43766d06b8113297',1,'util.h']]],
  ['schedulinginfo_296',['schedulingInfo',['../os__scheduling__strategies_8c.html#aadb0e3d669bbca5d4d424f4ba8724848',1,'os_scheduling_strategies.c']]],
  ['schedulinginformation_297',['SchedulingInformation',['../struct_scheduling_information.html',1,'SchedulingInformation'],['../os__scheduling__strategies_8h.html#a13aac67d6c5ae31dd05667417622ea64',1,'SchedulingInformation():&#160;os_scheduling_strategies.h']]],
  ['schedulingstrategy_298',['SchedulingStrategy',['../os__scheduler_8h.html#a19b2831a25a61b35337be0d5386f1098',1,'SchedulingStrategy():&#160;os_scheduler.h'],['../os__scheduler_8h.html#ac3ed7aa5fa89d4026cd86e4861ca7963',1,'SchedulingStrategy():&#160;os_scheduler.h']]],
  ['sethighnibble_299',['setHighNibble',['../os__memory_8c.html#a68640fd1f0d9f708b30091fa70ff9ee6',1,'os_memory.c']]],
  ['setlownibble_300',['setLowNibble',['../os__memory_8c.html#a706bb11a3d86c04a12526367ed7c3313',1,'os_memory.c']]],
  ['setmapentry_301',['setMapEntry',['../os__memory_8c.html#a9a3813198496fd4b10db2a6eedd27b99',1,'os_memory.c']]],
  ['size_302',['size',['../struct_param_stack.html#a25e5b12c36cd8d34de1455d7483a7da9',1,'ParamStack']]],
  ['snakebuffer_303',['SnakeBuffer',['../struct_snake_buffer.html',1,'']]],
  ['snakeelement_304',['SnakeElement',['../struct_snake_element.html',1,'']]],
  ['spos_20manual_305',['SPOS Manual',['../index.html',1,'']]],
  ['stack_5fsize_5fisr_306',['STACK_SIZE_ISR',['../defines_8h.html#a5897211c66fb513c0e45424e77446325',1,'defines.h']]],
  ['stack_5fsize_5fmain_307',['STACK_SIZE_MAIN',['../defines_8h.html#a0187f5405175817f5d15b70f2d5ba908',1,'defines.h']]],
  ['stack_5fsize_5fproc_308',['STACK_SIZE_PROC',['../defines_8h.html#a69935146762e044c13bc1e04e159ac7f',1,'defines.h']]],
  ['stackchecksum_309',['StackChecksum',['../os__process_8h.html#a45db48aaf651fca0006e612d9a3b4b9b',1,'os_process.h']]],
  ['stackpointer_310',['StackPointer',['../union_stack_pointer.html',1,'StackPointer'],['../os__process_8h.html#a52b6ead6aa07550bf81e7340e9d50e53',1,'StackPointer():&#160;os_process.h']]],
  ['success_311',['success',['../struct_page_result.html#a26ab3f163c9b9e0ab50d0325dac0b921',1,'PageResult']]]
];
