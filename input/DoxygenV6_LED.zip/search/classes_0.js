var searchData=
[
  ['color_317',['Color',['../struct_color.html',1,'']]]
];
