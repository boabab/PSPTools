var searchData=
[
  ['writesram_5finternal_316',['writeSRAM_internal',['../os__mem__drivers_8c.html#a36530bd7e06adc3f8b056b1caee1c802',1,'os_mem_drivers.c']]]
];
