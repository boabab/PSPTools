var searchData=
[
  ['heap_538',['Heap',['../os__memheap__drivers_8h.html#a705af815969c97892c0aaaa658f6c88c',1,'os_memheap_drivers.h']]]
];
