var searchData=
[
  ['extheap_5f_5f_523',['extHeap__',['../os__memheap__drivers_8h.html#a5fd7ae6e8a4b4961b8c925b2625c96b8',1,'os_memheap_drivers.h']]]
];
