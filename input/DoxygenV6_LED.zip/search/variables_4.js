var searchData=
[
  ['intheap_5f_5f_524',['intHeap__',['../os__memheap__drivers_8c.html#ab5abd3b149a45c1de26626e02fd13e78',1,'intHeap__():&#160;os_memheap_drivers.c'],['../os__memheap__drivers_8h.html#ab5abd3b149a45c1de26626e02fd13e78',1,'intHeap__():&#160;os_memheap_drivers.c']]],
  ['intsram_5f_5f_525',['intSRAM__',['../os__mem__drivers_8c.html#aa8eb994dbdb18634b2989d60336a385a',1,'intSRAM__():&#160;os_mem_drivers.c'],['../os__mem__drivers_8h.html#aa8eb994dbdb18634b2989d60336a385a',1,'intSRAM__():&#160;os_mem_drivers.c']]]
];
