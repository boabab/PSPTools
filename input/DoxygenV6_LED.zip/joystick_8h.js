var joystick_8h =
[
    [ "Direction", "joystick_8h.html#a224b9163917ac32fc95a60d8c1eec3aa", null ],
    [ "js_getButton", "joystick_8h.html#a95fd98bd17473dfc98b695b6ae48ad8d", null ],
    [ "js_getDirection", "joystick_8h.html#abf476663f675f8458d6b64b731c282bb", null ],
    [ "js_getHorizontal", "joystick_8h.html#a62ebc01b6ab2468d6570564506992aef", null ],
    [ "js_getVertical", "joystick_8h.html#a72fa2ac89ea1a9ef19b5e382b6221692", null ],
    [ "js_init", "joystick_8h.html#ae09a3f65a99e5399e0d7217410b81459", null ],
    [ "os_getJoystick", "joystick_8h.html#a66d68ddb7e8812a15c3a347802a7bc72", null ],
    [ "os_waitForJoystickButtonInput", "joystick_8h.html#a5292227d47b141f625d0891eda66a9fa", null ],
    [ "os_waitForNoJoystickButtonInput", "joystick_8h.html#a92da053d0a4a13ed64736c9e06802c42", null ]
];