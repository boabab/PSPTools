var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "a", "globals_func_a.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "j", "globals_func_j.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "o", "globals_func_o.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "w", "globals_func_w.html", null ]
];