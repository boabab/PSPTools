var joystick_8c =
[
    [ "js_getButton", "joystick_8c.html#a95fd98bd17473dfc98b695b6ae48ad8d", null ],
    [ "js_getDirection", "joystick_8c.html#abf476663f675f8458d6b64b731c282bb", null ],
    [ "js_getHorizontal", "joystick_8c.html#a62ebc01b6ab2468d6570564506992aef", null ],
    [ "js_getVertical", "joystick_8c.html#a72fa2ac89ea1a9ef19b5e382b6221692", null ],
    [ "js_init", "joystick_8c.html#ae09a3f65a99e5399e0d7217410b81459", null ],
    [ "os_getJoystick", "joystick_8c.html#a66d68ddb7e8812a15c3a347802a7bc72", null ],
    [ "os_waitForJoystickButtonInput", "joystick_8c.html#ad6a0def9c031150b32d494cda6d6d5f4", null ],
    [ "os_waitForNoJoystickButtonInput", "joystick_8c.html#aecbc2bffb13f39d76f9c9afcf5987929", null ]
];