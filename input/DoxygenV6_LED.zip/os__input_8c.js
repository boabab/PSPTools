var os__input_8c =
[
    [ "os_getInput", "os__input_8c.html#a137e8a89b9524ec791fffccedb04fef0", null ],
    [ "os_initInput", "os__input_8c.html#a47d043a57e87cffbb40be4e33609175a", null ],
    [ "os_waitForInput", "os__input_8c.html#a61782ddac46a1acdf81f35a4ad1e4d21", null ],
    [ "os_waitForNoInput", "os__input_8c.html#ad2eb8a84abf9fcfe88654e1118b351f5", null ]
];