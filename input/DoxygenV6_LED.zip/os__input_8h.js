var os__input_8h =
[
    [ "os_getInput", "os__input_8h.html#a137e8a89b9524ec791fffccedb04fef0", null ],
    [ "os_initInput", "os__input_8h.html#a9b42d5ff0c6b9d6f0cf93f9410d702a3", null ],
    [ "os_waitForInput", "os__input_8h.html#a3e58c42eac31b263a47c31815c14cff4", null ],
    [ "os_waitForNoInput", "os__input_8h.html#ab21d07133ad6992bb9b69c29cffdc692", null ]
];