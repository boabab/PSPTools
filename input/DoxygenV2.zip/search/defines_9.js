var searchData=
[
  ['os_5fallowed_5freset_5fsources_382',['OS_ALLOWED_RESET_SOURCES',['../os__core_8h.html#a70953382b3c375a3f6b848115532cd2d',1,'os_core.h']]],
  ['os_5ferror_383',['os_error',['../os__core_8h.html#aff56fb8e39e4b0db051157ca9b7bf57b',1,'os_core.h']]]
];
