var searchData=
[
  ['idle_29',['idle',['../os__scheduler_8c.html#a01131b63acf241e9db91704d89ce15d2',1,'os_scheduler.c']]],
  ['invalid_5fprocess_30',['INVALID_PROCESS',['../defines_8h.html#a455404d0cf6e4ea0b53f9f747e3744b1',1,'defines.h']]],
  ['isanyprocready_31',['isAnyProcReady',['../os__scheduling__strategies_8c.html#a28b49687a96acfbb30d9ac582fb65cf4',1,'os_scheduling_strategies.c']]],
  ['isr_32',['ISR',['../os__scheduler_8c.html#a5686c229bdef50123688ab6cb1404230',1,'ISR(TIMER2_COMPA_vect):&#160;os_scheduler.c'],['../util_8c.html#add2d7cdddfb682dcc0391e60cf42c7d6',1,'ISR(TIMER0_OVF_vect):&#160;util.c']]]
];
