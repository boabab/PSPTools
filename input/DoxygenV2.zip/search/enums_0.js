var searchData=
[
  ['accesspermission_314',['AccessPermission',['../os__user__privileges_8h.html#a79e573249a2843d17c2469e7f9d62899',1,'os_user_privileges.h']]]
];
