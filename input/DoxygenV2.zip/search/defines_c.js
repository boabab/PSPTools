var searchData=
[
  ['savecontext_387',['saveContext',['../util_8h.html#a95d67df1cf6117ce43766d06b8113297',1,'util.h']]],
  ['stack_5fsize_5fisr_388',['STACK_SIZE_ISR',['../defines_8h.html#a5897211c66fb513c0e45424e77446325',1,'defines.h']]],
  ['stack_5fsize_5fmain_389',['STACK_SIZE_MAIN',['../defines_8h.html#a0187f5405175817f5d15b70f2d5ba908',1,'defines.h']]],
  ['stack_5fsize_5fproc_390',['STACK_SIZE_PROC',['../defines_8h.html#a69935146762e044c13bc1e04e159ac7f',1,'defines.h']]]
];
