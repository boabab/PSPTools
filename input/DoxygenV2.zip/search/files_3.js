var searchData=
[
  ['os_5fcore_2ec_207',['os_core.c',['../os__core_8c.html',1,'']]],
  ['os_5fcore_2eh_208',['os_core.h',['../os__core_8h.html',1,'']]],
  ['os_5finput_2ec_209',['os_input.c',['../os__input_8c.html',1,'']]],
  ['os_5finput_2eh_210',['os_input.h',['../os__input_8h.html',1,'']]],
  ['os_5fprocess_2eh_211',['os_process.h',['../os__process_8h.html',1,'']]],
  ['os_5fscheduler_2ec_212',['os_scheduler.c',['../os__scheduler_8c.html',1,'']]],
  ['os_5fscheduler_2eh_213',['os_scheduler.h',['../os__scheduler_8h.html',1,'']]],
  ['os_5fscheduling_5fstrategies_2ec_214',['os_scheduling_strategies.c',['../os__scheduling__strategies_8c.html',1,'']]],
  ['os_5fscheduling_5fstrategies_2eh_215',['os_scheduling_strategies.h',['../os__scheduling__strategies_8h.html',1,'']]],
  ['os_5ftaskman_2eh_216',['os_taskman.h',['../os__taskman_8h.html',1,'']]],
  ['os_5fuser_5fprivileges_2eh_217',['os_user_privileges.h',['../os__user__privileges_8h.html',1,'']]]
];
