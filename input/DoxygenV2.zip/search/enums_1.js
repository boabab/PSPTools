var searchData=
[
  ['permissionrequest_315',['PermissionRequest',['../os__user__privileges_8h.html#a735a39b956d7cb00d379d841e24586db',1,'os_user_privileges.h']]],
  ['processstate_316',['ProcessState',['../os__process_8h.html#a373a58178f69d5e3e1de7516d105675e',1,'os_process.h']]]
];
