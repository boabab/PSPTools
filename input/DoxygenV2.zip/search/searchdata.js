var indexSectionsWithContent =
{
  0: "_abcdfilmnoprstuv",
  1: "prs",
  2: "adlou",
  3: "_adilo",
  4: "acloprst",
  5: "aps",
  6: "aprs",
  7: "o",
  8: "abcdfilmnoprsv",
  9: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

