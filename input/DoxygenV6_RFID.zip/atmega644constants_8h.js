var atmega644constants_8h =
[
    [ "AVR_CLOCK_FREQUENCY", "atmega644constants_8h.html#a6d7d59a0b0666c49383f6791665e05fe", null ],
    [ "AVR_MEMORY_EEPROM", "atmega644constants_8h.html#a56b0f5b86512c479a092c4e033118fb2", null ],
    [ "AVR_MEMORY_FLASH", "atmega644constants_8h.html#ae88c2094def41c06dfde9eb8647fae60", null ],
    [ "AVR_MEMORY_SRAM", "atmega644constants_8h.html#a473477a1f70b4ae3f9e63a3608f79cea", null ],
    [ "AVR_SRAM_END", "atmega644constants_8h.html#a9ad6add0d59a0afce1be5f596bd6eb63", null ],
    [ "AVR_SRAM_LAST", "atmega644constants_8h.html#a46178e81e94da6af60db5e242083eda3", null ],
    [ "AVR_SRAM_START", "atmega644constants_8h.html#a983f9c0a18785e2686728aaa4fc47f1e", null ],
    [ "F_CPU", "atmega644constants_8h.html#a43bafb28b29491ec7f871319b5a3b2f8", null ]
];