var searchData=
[
  ['readsram_5finternal_454',['readSRAM_internal',['../os__mem__drivers_8c.html#adb15019f570eaaef26ffa759a9feedc4',1,'os_mem_drivers.c']]],
  ['rfid_5finit_455',['rfid_init',['../os__rfid_8h.html#aeb5b07006c4691098e1b1da1a4164955',1,'os_rfid.c']]],
  ['rfid_5freceive_456',['rfid_receive',['../os__rfid_8h.html#aba04cabcf0575ca106946d0227c31507',1,'os_rfid.c']]]
];
