var searchData=
[
  ['pageresult_237',['PageResult',['../struct_page_result.html',1,'']]],
  ['pages_238',['pages',['../struct_param_stack.html#aad943c672912dfe5eaccf3af65c04dc2',1,'ParamStack']]],
  ['pagestate_239',['PageState',['../struct_page_state.html',1,'']]],
  ['param_240',['param',['../struct_page_state.html#af5db3df66a9031096e3aba02996aff42',1,'PageState']]],
  ['paramstack_241',['ParamStack',['../struct_param_stack.html',1,'']]],
  ['permissionrequest_242',['PermissionRequest',['../os__user__privileges_8h.html#a735a39b956d7cb00d379d841e24586db',1,'os_user_privileges.h']]],
  ['pqueue_5fappend_243',['pqueue_append',['../os__scheduling__strategies_8c.html#a3ae034c3452457a90dd7c074ca5c3aaf',1,'pqueue_append(ProcessQueue *queue, ProcessID pid):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a3ae034c3452457a90dd7c074ca5c3aaf',1,'pqueue_append(ProcessQueue *queue, ProcessID pid):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fdropfirst_244',['pqueue_dropFirst',['../os__scheduling__strategies_8c.html#af2fe5737d2380feb249f6798c75279e0',1,'pqueue_dropFirst(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#af2fe5737d2380feb249f6798c75279e0',1,'pqueue_dropFirst(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fgetfirst_245',['pqueue_getFirst',['../os__scheduling__strategies_8h.html#a91bfee52eb04e325a0be99bfc1fb00c0',1,'pqueue_getFirst(const ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8c.html#a91bfee52eb04e325a0be99bfc1fb00c0',1,'pqueue_getFirst(const ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fhasnext_246',['pqueue_hasNext',['../os__scheduling__strategies_8c.html#a7e9a431fcff0d687b1dba810ba80bc7e',1,'pqueue_hasNext(const ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a7e9a431fcff0d687b1dba810ba80bc7e',1,'pqueue_hasNext(const ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5finit_247',['pqueue_init',['../os__scheduling__strategies_8c.html#abcf6f70d0ed60b64437107c94ff0b9f7',1,'pqueue_init(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#abcf6f70d0ed60b64437107c94ff0b9f7',1,'pqueue_init(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fremovepid_248',['pqueue_removePID',['../os__scheduling__strategies_8c.html#affb2ae62bc6e6ae2502d9dba66c1e5a7',1,'pqueue_removePID(ProcessQueue *queue, ProcessID pid):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#affb2ae62bc6e6ae2502d9dba66c1e5a7',1,'pqueue_removePID(ProcessQueue *queue, ProcessID pid):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5freset_249',['pqueue_reset',['../os__scheduling__strategies_8c.html#aa6830b1c1886efadb22b77bcc0775a7c',1,'pqueue_reset(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#aa6830b1c1886efadb22b77bcc0775a7c',1,'pqueue_reset(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['priority_250',['Priority',['../os__process_8h.html#a1bb679f7ad1508e942e35da9a0e7eabf',1,'os_process.h']]],
  ['process_251',['Process',['../struct_process.html',1,'Process'],['../os__process_8h.html#a3b5b0413545e0d4ff600b0a7203e3086',1,'Process():&#160;os_process.h']]],
  ['process_5fstack_5fbottom_252',['PROCESS_STACK_BOTTOM',['../defines_8h.html#a5d7156541ae49491ce8c7c89dabf876a',1,'defines.h']]],
  ['processid_253',['ProcessID',['../os__process_8h.html#a9ae6ab2a896fd7ccf2c04cd38f9fa6c9',1,'os_process.h']]],
  ['processqueue_254',['ProcessQueue',['../struct_process_queue.html',1,'']]],
  ['processstate_255',['ProcessState',['../os__process_8h.html#a373a58178f69d5e3e1de7516d105675e',1,'ProcessState():&#160;os_process.h'],['../os__process_8h.html#a188e89ad1abd0d38668fb83d89aa8891',1,'ProcessState():&#160;os_process.h']]],
  ['program_256',['Program',['../os__process_8h.html#a1855c0ea815dd2a3323638f2fda0c38a',1,'os_process.h']]],
  ['program_5flinked_5flist_5fnode_257',['program_linked_list_node',['../structprogram__linked__list__node.html',1,'']]]
];
