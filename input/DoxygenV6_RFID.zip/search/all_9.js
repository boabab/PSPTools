var searchData=
[
  ['idle_39',['idle',['../os__scheduler_8c.html#a01131b63acf241e9db91704d89ce15d2',1,'os_scheduler.c']]],
  ['initmemorydevices_40',['initMemoryDevices',['../os__mem__drivers_8c.html#a7b4035516f05b473e63dcccfdcbb5ca3',1,'initMemoryDevices(void):&#160;os_mem_drivers.c'],['../os__mem__drivers_8h.html#a7b4035516f05b473e63dcccfdcbb5ca3',1,'initMemoryDevices(void):&#160;os_mem_drivers.c']]],
  ['initsram_5finternal_41',['initSRAM_internal',['../os__mem__drivers_8c.html#a8826af4dce682bd82546f1efc5ee7874',1,'os_mem_drivers.c']]],
  ['intheap_42',['intHeap',['../os__memheap__drivers_8h.html#a341c946d65a72577150d34439477dfe2',1,'os_memheap_drivers.h']]],
  ['intheap_5f_5f_43',['intHeap__',['../os__memheap__drivers_8c.html#ab5abd3b149a45c1de26626e02fd13e78',1,'intHeap__():&#160;os_memheap_drivers.c'],['../os__memheap__drivers_8h.html#ab5abd3b149a45c1de26626e02fd13e78',1,'intHeap__():&#160;os_memheap_drivers.c']]],
  ['intsram_44',['intSRAM',['../os__mem__drivers_8h.html#a30c012f8447ac02a80063f4250d01ea0',1,'os_mem_drivers.h']]],
  ['intsram_5f_5f_45',['intSRAM__',['../os__mem__drivers_8c.html#aa8eb994dbdb18634b2989d60336a385a',1,'intSRAM__():&#160;os_mem_drivers.c'],['../os__mem__drivers_8h.html#aa8eb994dbdb18634b2989d60336a385a',1,'intSRAM__():&#160;os_mem_drivers.c']]],
  ['invalid_5fprocess_46',['INVALID_PROCESS',['../defines_8h.html#a455404d0cf6e4ea0b53f9f747e3744b1',1,'defines.h']]],
  ['isanyprocready_47',['isAnyProcReady',['../os__scheduling__strategies_8c.html#a28b49687a96acfbb30d9ac582fb65cf4',1,'os_scheduling_strategies.c']]],
  ['isr_48',['ISR',['../os__scheduler_8c.html#a5686c229bdef50123688ab6cb1404230',1,'ISR(TIMER2_COMPA_vect):&#160;os_scheduler.c'],['../util_8c.html#add2d7cdddfb682dcc0391e60cf42c7d6',1,'ISR(TIMER0_OVF_vect):&#160;util.c']]]
];
