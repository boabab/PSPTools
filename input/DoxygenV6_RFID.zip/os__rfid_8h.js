var os__rfid_8h =
[
    [ "rfid_init", "os__rfid_8h.html#aeb5b07006c4691098e1b1da1a4164955", null ],
    [ "rfid_receive", "os__rfid_8h.html#aba04cabcf0575ca106946d0227c31507", null ]
];