var searchData=
[
  ['extheap_31',['extHeap',['../os__memheap__drivers_8h.html#a9d3e12d77e5d6a64c38d9d52a4aef469',1,'os_memheap_drivers.h']]],
  ['extheap_5f_5f_32',['extHeap__',['../os__memheap__drivers_8c.html#a5fd7ae6e8a4b4961b8c925b2625c96b8',1,'extHeap__():&#160;os_memheap_drivers.c'],['../os__memheap__drivers_8h.html#a5fd7ae6e8a4b4961b8c925b2625c96b8',1,'extHeap__():&#160;os_memheap_drivers.c']]],
  ['extsram_33',['extSRAM',['../os__mem__drivers_8h.html#aab38e0df15a7e7bbdc0de32e168b1daa',1,'os_mem_drivers.h']]],
  ['extsram_5f_5f_34',['extSRAM__',['../os__mem__drivers_8c.html#af1c3e9f7bf5ac9163ab28d4070dc6894',1,'extSRAM__():&#160;os_mem_drivers.c'],['../os__mem__drivers_8h.html#af1c3e9f7bf5ac9163ab28d4070dc6894',1,'extSRAM__():&#160;os_mem_drivers.c']]]
];
