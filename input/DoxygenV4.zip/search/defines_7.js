var searchData=
[
  ['intheap_500',['intHeap',['../os__memheap__drivers_8h.html#a341c946d65a72577150d34439477dfe2',1,'os_memheap_drivers.h']]],
  ['intsram_501',['intSRAM',['../os__mem__drivers_8h.html#a30c012f8447ac02a80063f4250d01ea0',1,'os_mem_drivers.h']]],
  ['invalid_5fprocess_502',['INVALID_PROCESS',['../defines_8h.html#a455404d0cf6e4ea0b53f9f747e3744b1',1,'defines.h']]]
];
