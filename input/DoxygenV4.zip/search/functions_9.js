var searchData=
[
  ['select_5fmemory_409',['select_memory',['../os__mem__drivers_8c.html#a586e4c730a90597fa3b966b59204f8f3',1,'os_mem_drivers.c']]],
  ['set_5foperation_5fmode_410',['set_operation_mode',['../os__mem__drivers_8c.html#aeddc5b11419e6ee3b50408ea1cc3ee89',1,'os_mem_drivers.c']]],
  ['sethighnibble_411',['setHighNibble',['../os__memory_8c.html#a68640fd1f0d9f708b30091fa70ff9ee6',1,'os_memory.c']]],
  ['setlownibble_412',['setLowNibble',['../os__memory_8c.html#a706bb11a3d86c04a12526367ed7c3313',1,'os_memory.c']]],
  ['setmapentry_413',['setMapEntry',['../os__memory_8c.html#a9a3813198496fd4b10db2a6eedd27b99',1,'os_memory.c']]]
];
