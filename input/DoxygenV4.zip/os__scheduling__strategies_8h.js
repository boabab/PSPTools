var os__scheduling__strategies_8h =
[
    [ "SchedulingInformation", "struct_scheduling_information.html", null ],
    [ "SchedulingInformation", "os__scheduling__strategies_8h.html#a13aac67d6c5ae31dd05667417622ea64", null ],
    [ "os_resetProcessSchedulingInformation", "os__scheduling__strategies_8h.html#aefdd44d05e14f2de4e9853aa83faf98c", null ],
    [ "os_resetSchedulingInformation", "os__scheduling__strategies_8h.html#af63ac803dcc59d7fe7f363c1cf6d5b66", null ],
    [ "os_Scheduler_Even", "os__scheduling__strategies_8h.html#ac02f13255b558aea53e8f1eaa41a9276", null ],
    [ "os_Scheduler_InactiveAging", "os__scheduling__strategies_8h.html#a8d6be305691317a13404a88690a0fd97", null ],
    [ "os_Scheduler_Random", "os__scheduling__strategies_8h.html#a8f2f73d597bc9ff4430b97e51715395d", null ],
    [ "os_Scheduler_RoundRobin", "os__scheduling__strategies_8h.html#acaf98d4ba249f6102399c690de5b53e8", null ],
    [ "os_Scheduler_RunToCompletion", "os__scheduling__strategies_8h.html#a06f1e2042bf3c973f052e13afa101ad4", null ]
];