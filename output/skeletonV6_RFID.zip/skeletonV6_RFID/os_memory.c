/*! \file
 *
 * Contains functions to allocate blocks of any spos-memory-drivers. We manage the blocks by
 * creating a lookup table with one nibble per byte payload. So we have 1/3 map and 2/3 use-heap of
 * each driver. Important: Always use addresses of the use-heap and convert them into the nibbles of
 * the map (only) if needed. For this purpose, there are helper functions such as
 * os_getMapEntry(...).
 *
 */

#include "os_memory.h"
#include "os_core.h"
#include "os_memory_strategies.h"
#include "util.h"

//----------------------------------------------------------------------------
// Functions
//----------------------------------------------------------------------------

/*!
 * Writes a value from 0x0 to 0xF to the lower nibble of the given address.
 *
 * @param heap     The heap that is written to
 * @param addr     The address on which the lower nibble is supposed to be changed
 * @param value    The value that the lower nibble of the given addr is supposed to get
 */
void setLowNibble(const Heap *heap, MemAddr addr, MemValue value) {
    // TODO implement.
}

/*!
 * Writes a value from 0x0 to 0xF to the higher nibble of the given address.
 *
 * @param heap     The heap that is written to
 * @param addr     The address on which the higher nibble is supposed to be changed
 * @param value    The value that the higher nibble of the given addr is supposed to get
 */
void setHighNibble(const Heap *heap, MemAddr addr, MemValue value) {
    // TODO implement.
}

/*!
 * Returns The value that can be found on the lower nibble of the given address
 *
 * @param heap     The heap that is read from
 * @param addr     The address which the lower nibble is supposed to be read from
 */
MemValue getLowNibble(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * Returns The value that can be found on the higher nibble of the given address
 *
 * @param heap     The heap that is read from
 * @param addr     The address which the higher nibble is supposed to be read from
 */
MemValue getHighNibble(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * This function is used to set a heap map entry on a specific heap.
 *
 * @param heap     The heap on whos map the entry is supposed to be set
 * @param addr     The address in use space for which the corresponding map entry shall be set
 * @param value    The value that is supposed to be set onto the map (valid range: 0x0 - 0xF)
 */
void setMapEntry(const Heap *heap, MemAddr addr, MemValue value) {
    // TODO implement.
}

/*!
 * This function is used to get a heap map entry on a specific heap Returns The value that can be
 * found on the heap map entry that corresponds to the given use space address
 *
 * @param heap     The heap from whos map the entry is supposed to be fetched
 * @param addr     The address in use space for which the corresponding map entry shall be fetched
 */
MemValue os_getMapEntry(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * This function is used to determine where a chunk starts if a given address might not point to the
 * start of the chunk but to some place inside of it. Returns The address that points to the first
 * byte of the chunk
 *
 * @param heap     The heap the chunk is on hand in
 * @param addr     The address that points to some byte of the chunk
 */
MemAddr os_getFirstByteOfChunk(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * This function determines the value of the first nibble of a chunk. Returns The map entry that
 * corresponds to the first byte of the chunk
 *
 * @param heap     The heap the chunk is on hand in
 * @param addr     The address that points to some byte of the chunk
 */
ProcessID getOwnerOfChunk(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * Takes a use-pointer and computes the length of the chunk. This only works for occupied chunks.
 * The size of free chunks is always 0. Returns The chunk's length.
 *
 * @param heap     The driver to be used.
 * @param addr     An address of the use-heap.
 */
uint16_t os_getChunkSize(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * Frees a chunk of allocated memory on the medium given by the driver. This function checks if the
 * call has been made by someone with the right to do it (i.e. the process that owns the memory or
 * the OS). This function is made in order to avoid code duplication and is called by several
 * functions that, in some way, free allocated memory such as os_freeProcessMemory/os_free...
 *
 * @param heap     The driver to be used.
 * @param addr     An address inside of the chunk (not necessarily the start).
 * @param owner    The expected owner of the chunk to be freed
 */
void os_freeOwnerRestricted(Heap *heap, MemAddr addr, ProcessID owner) {
    // TODO implement.
}

/*!
 * Allocates a chunk of memory on the medium given by the driver. This funktion will allocate memory
 * for the given owner. This function is made in order to avoid code duplication and is called
 * os_malloc and os_sh_malloc Returns A pointer to the first Byte of the allocated chunk. 0 if
 * allocation fails (0 is never a valid address).
 *
 * @param heap     The driver to be used.
 * @param size     The amount of memory to be allocated in Bytes. Must be able to handle a single
 *                byte and values greater than 255.
 * @param owner    The ProcessID of the owner of the new chunk
 */
MemAddr os_mallocOwner(Heap *heap, size_t size, ProcessID owner) {
    // TODO implement.
}

/*!
 * Allocates a chunk of memory on the medium given by the driver and reserves it as shared memory.
 * Returns A pointer to the first Byte of the allocated chunk. 0 if allocation fails (0 is never a
 * valid address).
 *
 * @param heap     The heap to be used.
 * @param size     The amount of memory to be allocated in Bytes. Must be able to handle a single
 *                byte and values greater than 255.
 */
MemAddr os_sh_malloc(Heap *heap, size_t size) {
    // TODO implement.
}

/*!
 * Frees a chunk of shared allocated memory on the given heap
 *
 * @param heap     The heap to be used.
 * @param addr     An address inside of the chunk (not necessarily the start).
 */
void os_sh_free(Heap *heap, MemAddr *addr) {
    // TODO implement.
}

/*!
 * Opens a chunk of shared memory to prepare a reading process Returns MemAddr is the dereferenced
 * argument ptr after opening the chunk
 *
 * @param heap     The heap to be used
 * @param ptr      Pointer to an address of the chunk
 */
MemAddr os_sh_readOpen(const Heap *heap, const MemAddr *ptr) {
    // TODO implement.
}

/*!
 * Opens a chunk of shared memory to prepare a writing process Returns MemAddr is the dereferenced
 * argument ptr after opening the chunk
 *
 * @param heap     The heap to be used
 * @param ptr      Pointer to an address of the chunk
 */
MemAddr os_sh_writeOpen(const Heap *heap, const MemAddr *ptr) {
    // TODO implement.
}

/*!
 * Closes a chunk of shared memory to end an arbitrary access
 *
 * @param heap     The heap to be used
 * @param addr     Address of the chunk
 */
void os_sh_close(const Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * Function used to write onto shared memory
 *
 * @param heap     The heap to be used
 * @param ptr      Pointer to an address of the chunk to write to
 * @param offset   An offset that refers to the beginning of the chunk
 * @param dataSrc  Source of the data (this is always on internal SRAM)
 * @param length   Specifies how many bytes of data shall be written
 */
void os_sh_write(const Heap *heap, const MemAddr *ptr, uint16_t offset, const MemValue *dataSrc, uint16_t length) {
    // TODO implement.
}

/*!
 * Function used to read from shared memory
 *
 * @param heap     The heap to be used
 * @param ptr      Pointer to an address of the chunk to read from
 * @param offset   An offset that refers to the beginning of the chunk
 * @param dataDest Destination where the data shall be copied to (this is always on internal SRAM)
 * @param length   Specifies how many bytes of data shall be read
 */
void os_sh_read(const Heap *heap, const MemAddr *ptr, uint16_t offset, MemValue *dataDest, uint16_t length) {
    // TODO implement.
}

/*!
 * Allocates a chunk of memory on the medium given by the driver and reserves it for the current
 * process. Returns A pointer to the first Byte of the allocated chunk. 0 if allocation fails (0 is
 * never a valid address).
 *
 * @param heap     The driver to be used.
 * @param size     The amount of memory to be allocated in Bytes. Must be able to handle a single
 *                byte and values greater than 255.
 */
MemAddr os_malloc(Heap *heap, size_t size) {
    // TODO implement.
}

/*!
 * Frees a chunk of allocated memory of the currently running process on the given heap
 *
 * @param heap     The driver to be used.
 * @param addr     An address inside of the chunk (not necessarily the start).
 */
void os_free(Heap *heap, MemAddr addr) {
    // TODO implement.
}

/*!
 * The Heap-map-size of the heap (needed by the taskmanager) Returns The size of the map of the heap
 *
 * @param heap     The heap to be used.
 */
size_t os_getMapSize(const Heap *heap) {
    // TODO implement.
}

/*!
 * The Heap-use-size of the heap (needed by the taskmanager) Returns The size of the use-area of the
 * heap
 *
 * @param heap     The heap to be used.
 */
size_t os_getUseSize(const Heap *heap) {
    // TODO implement.
}

/*!
 * The Map-start of the heap (needed by the taskmanager) Returns The first byte of the map of the
 * heap
 *
 * @param heap     The heap to be used.
 */
MemAddr os_getMapStart(const Heap *heap) {
    // TODO implement.
}

/*!
 * The Heap-use-start of the heap (needed by the taskmanager) Returns The first byte of the use-area
 * of the heap
 *
 * @param heap     The heap to be used.
 */
MemAddr os_getUseStart(const Heap *heap) {
    // TODO implement.
}

/*!
 * Simple setter function to change the allocation strategy of a given heap
 *
 * @param heap     The heap of which the allocation strategy shall be changed
 * @param allocStrat The strategy is changed to allocStrat
 */
void os_setAllocationStrategy(Heap *heap, AllocStrategy allocStrat) {
    // TODO implement.
}

/*!
 * Simple getter function to fetch the allocation strategy of a given heap Returns The allocation
 * strategy of the given heap
 *
 * @param heap     The heap of which the allocation strategy is returned
 */
AllocStrategy os_getAllocationStrategy(const Heap *heap) {
    // TODO implement.
}

/*!
 * This function realises the garbage collection. When called, every allocated memory chunk of the
 * given process is freed
 *
 * @param heap     The heap on which we look for allocated memory
 * @param pid      The ProcessID of the process that owns all the memory to be freed
 */
void os_freeProcessMemory(Heap *heap, ProcessID pid) {
    // TODO implement.
}

/*!
 * This will move one Chunk to a new location , To provide this the content of the old one is copied
 * to the new location, as well as all Map Entries are set properly since this is a helper function
 * for reallocation, it only works if the new Chunk is bigger than the old one.
 *
 * @param heap     The heap where the Moving takes place
 * @param oldChunk The first Address of the old Chunk that is to be moved
 * @param oldSize  The size of the old Chunk
 * @param newChunk The first Address of the new Chunk
 * @param newSize  The size of the new Chunk
 */
void moveChunk(Heap *heap, MemAddr oldChunk, size_t oldSize, MemAddr newChunk, size_t newSize) {
    // TODO implement.
}

/*!
 * This is an efficient reallocation routine. It is used to resize an existing allocated chunk of
 * memory. If possible, the position of the chunk remains the same. It is only searched for a
 * completely new chunk if everything else does not fit For a more detailed description please use
 * the exercise document. Returns First adress (in use space) of the newly allocated chunk
 *
 * @param heap     The heap on which the reallocation is performed
 * @param addr     One adress inside of the chunk that is supposed to be reallocated
 * @param size     The size the new chunk is supposed to have
 */
MemAddr os_realloc(Heap *heap, MemAddr addr, uint16_t size) {
    // TODO implement.
}
